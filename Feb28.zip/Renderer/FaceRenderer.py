import torch.nn as nn
import numpy as np
from .ParametricFaceModel import ParametricFaceModel
from .MeshRenderer import MeshRenderer
import torch

class FaceRenderer(nn.Module):
    def __init__(self, bfm_path, resolution):
        super(FaceRenderer, self).__init__()

        camera_distance = 10.
        focal = 1015 / 224 * resolution
        center = resolution / 2
        rasterize_size = resolution
        fov = 2 * np.arctan(center / focal) * 180 / np.pi
        znear = 5.0
        zfar = 15.0

        self.FaceModel = ParametricFaceModel(bfm_path, camera_distance=camera_distance, focal=focal, center=center)
        self.Renderer = MeshRenderer(fov, znear, zfar, rasterize_size, use_opengl=False)

    def forward(self, x):
        face_vertex, face_normal, face_texture, face_color, depth_vertex, landmark = self.FaceModel(x)
        mask, depth, image, texture, normal = self.Renderer(face_vertex, self.FaceModel.face_buf, feat=[face_color, face_texture, face_normal, depth_vertex])

        image = image * 2 - 1 # Change the range to [-1, 1]
        texture = texture * 2 - 1 # Change the range to [-1, 1]

        Zeros = torch.zeros_like(image, device=image.device)
        image = image * mask + Zeros * (1 - mask)
        texture = texture * mask + Zeros * (1 - mask)
        normal = normal * mask + Zeros * (1 - mask)
        
        lighting = image - texture

        return mask, image, texture, normal, lighting, depth